package model;

public interface ModeDePaiement{

    // Attributs
    public static final double POURCENTAGE = 0.02;

    // Accesseurs et mutateurs
    public double getFrais();
    public void setFrais(double frais);

}
